package com.dicoding.mygithub.UI

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.mygithub.Adapter.PenggunaAdapter
import com.dicoding.mygithub.Response.ItemsItem
import com.dicoding.mygithub.Model.MainViewModel
import com.dicoding.mygithub.databinding.ActivityMainBinding

class MainActivity: AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()

        val mainViewModel = ViewModelProvider(this)[MainViewModel::class.java]

        val layoutManager = LinearLayoutManager(this)
        binding.rvPengguna.layoutManager = layoutManager
        val itemDecoration = DividerItemDecoration(this, layoutManager.orientation)
        binding.rvPengguna.addItemDecoration(itemDecoration)

        mainViewModel.githubUser.observe(this) {users ->
            githubUser(users)
        }
        mainViewModel.isLoading.observe(this) {
            showLoading(it)
        }

        with(binding) {
            searchView.setupWithSearchBar(searchBar)
            searchView.editText.setOnEditorActionListener { _, _, _ ->
                val user = searchView.text
                searchView.hide()
                mainViewModel.findByUsername(user.toString())
                false
            }
        }

    }

    private fun showLoading(isLoading: Boolean) {
        binding.loading.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

    private fun githubUser(items: List<ItemsItem>?) {
        val adapter = PenggunaAdapter()
        adapter.submitList(items)
        binding.rvPengguna.adapter = adapter
    }
}