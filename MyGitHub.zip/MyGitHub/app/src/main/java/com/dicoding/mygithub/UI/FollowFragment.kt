package com.dicoding.mygithub.UI

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.mygithub.Adapter.PengikutAdapter
import com.dicoding.mygithub.Response.ItemsItem
import com.dicoding.mygithub.databinding.FragmentFollowBinding
import com.dicoding.mygithub.Model.PengikutModel


class FollowFragment : Fragment() {
    private lateinit var _binding: FragmentFollowBinding
    private var adapter = PengikutAdapter()

    private var username: String = ""
    private var position: Int = 0

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFollowBinding.inflate(inflater, container, false)
        return _binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val viewModelProvider = ViewModelProvider(this)
        val followingModel = viewModelProvider.get(PengikutModel::class.java)

        val layoutManager = LinearLayoutManager(requireActivity())
        _binding.rvPengguna.layoutManager = layoutManager
        val itemDecoration = DividerItemDecoration(requireActivity(), layoutManager.orientation)
        _binding.rvPengguna.addItemDecoration(itemDecoration)

        val arg = arguments
        arg?.let {
            username = it.getString(ARG_USERNAME) ?: ""
            position = it.getInt(ARG_POSITION)
        }

        when (position) {
            0 -> {
                followingModel.getUserFollower(username)
                followingModel.userFollower.observe(viewLifecycleOwner) { pengikut ->
                    recyclerViewSetUp(pengikut)
                }
            }
            1 -> {
                followingModel.getUserFollowing(username)
                followingModel.userFollowing.observe(viewLifecycleOwner) { mengikuti ->
                    recyclerViewSetUp(mengikuti)
                }
            }
            else -> {
                Log.d("FollowFragment", "Position: $position")
            }
        }
        followingModel.isLoading.observe(viewLifecycleOwner) {
            showLoading(it)
        }
    }

    private fun recyclerViewSetUp(userFollow: List<ItemsItem>) {
        _binding.rvPengguna.adapter = adapter
        userFollow?.let {
            adapter.submitList(it)
        }
    }

    private fun showLoading(isLoading: Boolean) {
        _binding.loading.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

    companion object {
        const val ARG_POSITION = "arg_position"
        const val ARG_USERNAME = "arg_username"
    }
}
