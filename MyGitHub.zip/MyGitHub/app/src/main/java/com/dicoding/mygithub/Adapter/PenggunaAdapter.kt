package com.dicoding.mygithub.Adapter

import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.dicoding.mygithub.Response.ItemsItem
import com.dicoding.mygithub.UI.DetailView
import com.dicoding.mygithub.databinding.ItemUserBinding

class PenggunaAdapter : androidx.recyclerview.widget.ListAdapter<ItemsItem, PenggunaAdapter.MyViewHolder>(DIFF_CALLBACK) {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val binding = ItemUserBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MyViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val users = getItem(position)
        holder.bindUser(users)
    }

    class MyViewHolder(val binding: ItemUserBinding): RecyclerView.ViewHolder(binding.root) {
        fun bindUser(users: ItemsItem){
            binding.apply {
                tvItemName.text = users.login
                Glide.with(itemView.context)
                    .load(users.avatarUrl)
                    .into(imgItemPhoto)
            }
            binding.cardView.setOnClickListener {
                val intent = Intent(itemView.context, DetailView::class.java)
                intent.putExtra(DetailView.EXTRA_USER, users.login)
                itemView.context.startActivity(intent)
            }
        }
    }

    companion object {
        val DIFF_CALLBACK = object : DiffUtil.ItemCallback<ItemsItem>() {
            override fun areItemsTheSame(oldItem: ItemsItem, newItem: ItemsItem): Boolean {
                return oldItem == newItem
            }

            override fun areContentsTheSame(oldItem: ItemsItem, newItem: ItemsItem): Boolean {
                return oldItem == newItem
            }
        }
    }
}