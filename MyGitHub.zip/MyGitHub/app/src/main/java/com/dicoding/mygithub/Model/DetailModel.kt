package com.dicoding.mygithub.Model

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.dicoding.mygithub.Response.DetailResponPengguna
import com.dicoding.mygithub.Retrofit.Apiconfig
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DetailModel : ViewModel() {
    private val _detailUser = MutableLiveData<DetailResponPengguna>()
    val detailPengguna : LiveData<DetailResponPengguna> = _detailUser

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading : LiveData<Boolean> = _isLoading

    fun getDetailPengguna(username: String) {
        _isLoading.value = true
        val client = Apiconfig.getApiService().getDetailPengguna(username)
        client.enqueue(object : Callback<DetailResponPengguna> {
            override fun onResponse(
                call: Call<DetailResponPengguna>,
                response: Response<DetailResponPengguna>
            ) {
                _isLoading.value = false
                if (response.isSuccessful) {
                    _detailUser.value = response.body()
                } else {
                    Log.e(TAG, "onFailure: ${response.message()}")
                }
            }

            override fun onFailure(call: Call<DetailResponPengguna>, t: Throwable) {
                _isLoading.value = false
                Log.e(TAG, "onFailure: ${t.message.toString()}")
            }
        })
    }

    companion object {
        private const val TAG = "DetailViewModel"

    }
}