package com.dicoding.mygithub.Model

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.dicoding.mygithub.Response.GitHubResponse
import com.dicoding.mygithub.Response.ItemsItem
import com.dicoding.mygithub.Retrofit.Apiconfig
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainViewModel : ViewModel() {
    private val _githubuser = MutableLiveData<List<ItemsItem>>()
    val githubUser : LiveData<List<ItemsItem>> = _githubuser

    private val _isloading = MutableLiveData<Boolean>()
    val isLoading : LiveData<Boolean> = _isloading

    init {
        findGithubUser()
    }

    fun findByUsername(name: String) {
        findGithubUser(name)
    }

    fun findGithubUser(query: String = "ardhan") {
        _isloading.value = true
        val client = Apiconfig.getApiService().getUsers(query)
        client.enqueue(object : Callback<GitHubResponse> {
            override fun onResponse(
                call: Call<GitHubResponse>,
                response: Response<GitHubResponse>
            ) {
                _isloading.value = false
                if (response.isSuccessful) {
                    _githubuser.value = response.body()?.items
                } else {
                    Log.e(TAG, "onFailure: ${response.message()}")
                }
            }
            override fun onFailure(call: Call<GitHubResponse>, t: Throwable) {
                _isloading.value = false
                Log.e(TAG, "onFailure: ${t.message.toString()}")
            }
        })
    }
    companion object{
        private const val TAG = "MainViewModel"
    }
}