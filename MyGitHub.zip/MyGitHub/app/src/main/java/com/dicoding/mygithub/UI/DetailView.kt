package com.dicoding.mygithub.UI

import android.os.Bundle
import android.view.View
import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.dicoding.mygithub.Adapter.PagerAdapter
import com.dicoding.mygithub.R
import com.dicoding.mygithub.Response.DetailResponPengguna
import com.dicoding.mygithub.databinding.ActivityDetailViewBinding
import com.dicoding.mygithub.Model.DetailModel
import com.google.android.material.tabs.TabLayoutMediator

class DetailView : AppCompatActivity() {
    private lateinit var binding: ActivityDetailViewBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailViewBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val detailuser = intent.getStringExtra(EXTRA_USER)
        if (detailuser != null) {
            val viewModel = ViewModelProvider(
                this,
                ViewModelProvider.NewInstanceFactory()
            ).get(DetailModel::class.java)
            viewModel.getDetailPengguna(detailuser)

            viewModel.detailPengguna.observe(this) { user ->
                setDetailUser(user)
            }
            viewModel.isLoading.observe(this) { isLoading ->
                showLoading(isLoading)
            }
        } else {
            finish()
        }

        val sectionPagerAdapter = PagerAdapter(this)
        sectionPagerAdapter.username = detailuser.toString()
        val viewPager = binding.viewPager
        viewPager.adapter = sectionPagerAdapter
        val tabs = binding.tabs
        TabLayoutMediator(tabs, viewPager) { tab, position ->
            tab.text = resources.getString(TAB_TITLES[position])
        }.attach()
        supportActionBar?.elevation = 0f
    }

    private fun setDetailUser(user: DetailResponPengguna) {
        binding.apply {
            nama.text = user.name
            username.text = user.login
            numPengikut.text = user.followers.toString()
            numMengikuti.text = user.following.toString()
            Glide.with(this@DetailView)
                .load(user.avatarUrl)
                .into(imgItemPhoto)
        }
    }

    private fun showLoading(isLoading: Boolean) {
        binding.loading.visibility = if (isLoading) View.VISIBLE else View.GONE
    }


    companion object {
        const val EXTRA_USER = "extra_user"

        @StringRes
        private val TAB_TITLES = intArrayOf(
            R.string.follower_bar,
            R.string.following_bar
        )
    }
}
