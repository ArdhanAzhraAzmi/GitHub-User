package com.dicoding.mygithub.Adapter

import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.dicoding.mygithub.Response.ItemsItem
import com.dicoding.mygithub.UI.DetailView
import com.dicoding.mygithub.databinding.ItemUserBinding

class PengikutAdapter : RecyclerView.Adapter<PengikutAdapter.FollowViewHolder>() {
    private var userFollow: List<ItemsItem> = ArrayList()

    inner class FollowViewHolder(val binding: ItemUserBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FollowViewHolder {
        val binding = ItemUserBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return FollowViewHolder(binding)
    }

    override fun getItemCount(): Int = userFollow.size

    override fun onBindViewHolder(holder: FollowViewHolder, position: Int) {
        val currentItem = userFollow[position]

        with(holder) {
            binding.apply {
                tvItemName.text = currentItem.login
                Glide.with(itemView.context)
                    .load(currentItem.avatarUrl)
                    .into(imgItemPhoto)

                itemView.setOnClickListener {
                    val intent = Intent(itemView.context, DetailView::class.java)
                    intent.putExtra(DetailView.EXTRA_USER, currentItem.login)
                    itemView.context.startActivity(intent)
                }
            }
        }
    }

    fun submitList(newList: List<ItemsItem>) {
        userFollow = newList
        notifyDataSetChanged()
    }
}