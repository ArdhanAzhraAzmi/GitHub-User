package com.dicoding.mygithub.Retrofit

import com.dicoding.mygithub.Response.DetailResponPengguna
import com.dicoding.mygithub.Response.GitHubResponse
import com.dicoding.mygithub.Response.ItemsItem
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {
    @GET("search/users")
    fun getUsers(
        @Query("q") username: String
    ): Call<GitHubResponse>

    @GET("users/{username}")
    fun getDetailPengguna(@Path("username") username: String): Call<DetailResponPengguna>

    @GET("users/{username}/followers")
    fun getPengikut(@Path("username") username: String): Call<List<ItemsItem>>
    @GET("users/{username}/following")
    fun getMengikuti(@Path("username") username: String): Call<List<ItemsItem>>

}